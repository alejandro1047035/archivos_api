const op=require('./hola');
op.saludar("juanchopolo");
op.potencia(9,3);

