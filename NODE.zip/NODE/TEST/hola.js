function saludar(nombre)
{
    console.log("hola bienvenido a node js");
}

function potencia(base,exponente)
{
    var res =Math.pow(base,exponente);
    console.log(base,"elevado a",exponente,"es",res);
}
exports.saludar= saludar;
exports.potencia= potencia;

///saludar("Daniel GM");
//potencia(2,5);
