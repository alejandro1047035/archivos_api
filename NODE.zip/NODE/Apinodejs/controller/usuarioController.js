const conexion = require('../config/conexion');
const express = require("express");
const ruta = express();
// para capturar los parametrosâ€‹
const bodyParser = require('body-parser');
ruta.use(bodyParser.json())  

//-------------------------------â€‹
//http://localhost:3300/
ruta.get('/', function(req, res) {
    res.json({ mensaje: ' ¡estoy  Index Usuario!' })  

  })
//--------- obtener todos los usuarios por get
ruta.get('/usuarios/',function(req,res){
    //res.json({ mensaje: '¡listando todos los Usuario!' }) 
 let sql="select * from usuarios order by id"
  conexion.query(sql,(err,rows)=>{
      if(err) throw err;
      else{
          res.json(rows)
      }
  }) 
});

//--------- obtener un usuarios por get dado su id
ruta.get('/usuarios/:id',function(req,res){
    //res.json({ mensaje: '¡listando un Usuario por id!' })  
    conexion.query("select * from usuarios where id = ?", [req.params.id],(err,rows)=>{
        if(err) throw err;
        else{
            res.json(rows)
        }
    })
});

//--------- guardar un usuarios en BD
ruta.post('/usuarios/',function(req,res){
    let sql = "insert into  usuarios set ?"
   console.log('Registro recibido: ',req.body);
    let poststr = {
        documento: req.body.documento,
        nombres : req.body.nombres,
        apellidos: req.body.apellidos,
        direccion: req.body.direccion,
        telefono: req.body.telefono,
        correo: req.body.correo
       }
       conexion.query(sql, poststr, function (error, results) {
        if (error) throw error;
        if (results.affectedRows) {
         res.json({mensaje: 'Registro guardado'})
       }
       else
         res.json({mensaje: 'No se pudo guardar'})
      }); 
});

//--------- actualizar un usuarios en BD
ruta.put('/usuarios/',function(req,res){
    //res.json({ mensaje: '¡Actualizando un Usuario!' })  
    let sql = "update usuarios set documento=?, nombres= ?,apellidos = ?,direccion =?, telefono = ?,correo= ? where id = ?"
    conexion.query(sql, [req.body.documento,req.body.nombres,req.body.apellidos,req.body.direccion,req.body.telefono,req.body.correo,req.body.id], function (error, results) {
       if (error) throw error;
       if (results.affectedRows) {
        res.json({mensaje: 'Registro actualizado'})
      }
      else
        res.json({mensaje: 'No se pudo actualizar'})
     });
});

//--------- Borrar un usuarios por get dado su id
ruta.delete('/usuarios/:id',function(req,res){
    let sql ="delete from usuarios where id = ?"
    conexion.query(sql, [req.params.id], function (error, results) {
       if (error) throw error;
       if (results.affectedRows) {
         res.json({mensaje: 'Registro eliminado'})
       }
       else
         res.json({mensaje: 'No se pudo eliminar'})
     }); 
});

 
module.exports = ruta;