import { Component } from '@angular/core';
import { Usuario } from 'src/app/model/Usuario';
import { UsuarioService } from 'src/app/servicio/usuario.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-crear-usuario',
  templateUrl: './crear-usuario.component.html',
  styleUrls: ['./crear-usuario.component.css']
})
export class CrearUsuarioComponent {
  usuario : Usuario ={
    id:0,
    documento: '',
    nombres: '',
    apellidos: '',
    direccion: '',
    telefono: '',
    correo: ''
  };
  constructor(private servicio:UsuarioService,private ruta:Router){}
  //---------- guaradar el usuario del formulario
  guardarUsuario()
  {
    this.servicio.saveUsuario(this.usuario).subscribe(
      (datos:any)=> {alert(datos['mensaje'])},
      (error)=> {console.log(error)}
    )
    this.listarUsuario();
  }

  listarUsuario()
  {
    return this.ruta.navigate(['/listar-usuario/']);
  }

}//EndClass
