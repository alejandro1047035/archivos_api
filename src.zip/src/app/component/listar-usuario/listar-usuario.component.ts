import { Component, OnInit } from '@angular/core';
import { UsuarioService } from 'src/app/servicio/usuario.service';

import { Router } from '@angular/router';

@Component({
  selector: 'app-listar-usuario',
  templateUrl: './listar-usuario.component.html',
  styleUrls: ['./listar-usuario.component.css']
})
export class ListarUsuarioComponent implements OnInit {
 usuarios:any;
 constructor(private servicio:UsuarioService,private ruta:Router){}
 ngOnInit(): void {
   this.showUsuarios();
 }
  showUsuarios(){
    return this.servicio.getALL().subscribe(result => this.usuarios=result);
  

 }//end classs
//--- recibe el id a eliminar y llama a la API
eliminarUsuario(id:string)
{
  console.log("Preparado para eliminar el "+id);
  return this.servicio.deleteUsuario(id).subscribe(
    (datos:any) =>{
      if(datos['mensaje'])
      {
      alert(datos['mensaje']);
      }
      this.showUsuarios();
    
    },
    (error) => {console.log('Ocurrió un error ',error)}
  )
}

//------ llame al otro componente crear usuario---
nuevoUsuario(){
  return this.ruta.navigate(['/crear-usuario/']);
}

//---- edita el cliente
editarUsuario(id:string)
{
   this.ruta.navigate(['/actualizar-usuario/'+id]);
}

}
