import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ActualizarUsuarionComponent } from './actualizar-usuarion.component';

describe('ActualizarUsuarionComponent', () => {
  let component: ActualizarUsuarionComponent;
  let fixture: ComponentFixture<ActualizarUsuarionComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ActualizarUsuarionComponent]
    });
    fixture = TestBed.createComponent(ActualizarUsuarionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
