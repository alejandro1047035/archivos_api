import { Component } from '@angular/core';

@Component({
  selector: 'app-actualizar-usuarion',
  templateUrl: './actualizar-usuarion.component.html',
  styleUrls: ['./actualizar-usuarion.component.css']
})
export class ActualizarUsuarionComponent {

}
