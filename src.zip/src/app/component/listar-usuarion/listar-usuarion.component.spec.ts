import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListarUsuarionComponent } from './listar-usuarion.component';

describe('ListarUsuarionComponent', () => {
  let component: ListarUsuarionComponent;
  let fixture: ComponentFixture<ListarUsuarionComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ListarUsuarionComponent]
    });
    fixture = TestBed.createComponent(ListarUsuarionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
