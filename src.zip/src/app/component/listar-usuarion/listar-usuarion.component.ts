import { Component, OnInit } from '@angular/core';
import { UsuarioService } from 'src/app/servicio/usuario.service';
@Component({
  selector: 'app-listar-usuarion',
  templateUrl: './listar-usuarion.component.html',
  styleUrls: ['./listar-usuarion.component.css']
})
export class ListarUsuarionComponent implements OnInit {
usuarios:any;
constructor(private servicio: UsuarioService){}
ngOnInit(): void {
    this.showUsuarios();
}

showUsuarios()
{
  return this.servicio.getAll().subscribe(result => this.usuarios=result)
}

eliminarUsuario(id:string)
{
  console.log("Preparado para eliminar el "+id);
  return this.servicio.deleteUsuario(id).subscribe(
    (datos:any) =>{
      if(datos['status'])
      {
      alert(datos['status']);
      }
      //this.showAll();
    
    },
    (error) => {console.log('Ocurrió un error ',error)}
  )
}

}
