import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Usuario } from 'src/app/model/Usuario';
import { UsuarioService } from 'src/app/servicio/usuario.service';

@Component({
  selector: 'app-actualizar-usuario',
  templateUrl: './actualizar-usuario.component.html',
  styleUrls: ['./actualizar-usuario.component.css']
})
export class ActualizarUsuarioComponent implements OnInit{

  usuario : Usuario ={
    id:0,
    documento: '',
    nombres: '',
    apellidos: '',
    direccion: '',
    telefono: '',
    correo: ''
  };
  
  constructor(private servicio:UsuarioService,private ruta:Router, private activaterouter:ActivatedRoute){}

  ngOnInit(): void {
    let id = this.activaterouter.snapshot.paramMap.get('id');
    console.log(' Recibio para editar ',id);
    
    if(id)//si viene el id
    {
      this.servicio.getUsuario(id).subscribe(
        (resultado:any) =>{
          this.usuario=resultado[0];//formulario
         //console.log("registro completo: ",this.cliente);
        },
        (error) =>{console.log("error ",error)}
      );
    }
  }

    //---- actualizar Cliente llamando la API
    actualizarUsuario()
    {
      
      this.servicio.updateUsuario(this.usuario).subscribe(
        (res:any) => {
          if(res['mensaje'])
          {
            alert(res['mensaje']);
            this.listarUsuario();
          }
        },
        (error) => { console.log("Error generado: ",error)}
      );
  
    }
    //--- envvia para el modulo listarCliente
    listarUsuario()
    {
      this.ruta.navigate(['/listar-usuario/']);
    }
  
  
}//EndClass
