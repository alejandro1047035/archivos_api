import { Component } from '@angular/core';

@Component({
  selector: 'app-crear-usuarion',
  templateUrl: './crear-usuarion.component.html',
  styleUrls: ['./crear-usuarion.component.css']
})
export class CrearUsuarionComponent {

}
