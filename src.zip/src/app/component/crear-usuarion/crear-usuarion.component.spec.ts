import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CrearUsuarionComponent } from './crear-usuarion.component';

describe('CrearUsuarionComponent', () => {
  let component: CrearUsuarionComponent;
  let fixture: ComponentFixture<CrearUsuarionComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CrearUsuarionComponent]
    });
    fixture = TestBed.createComponent(CrearUsuarionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
