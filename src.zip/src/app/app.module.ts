import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ListarUsuarioComponent } from './component/listar-usuario/listar-usuario.component';
import { CrearUsuarioComponent } from './component/crear-usuario/crear-usuario.component';
import { ActualizarUsuarioComponent } from './component/actualizar-usuario/actualizar-usuario.component';
import { HttpClientModule } from '@angular/common/http'; 
import {FormsModule, ReactiveFormsModule}  from '@angular/forms'
@NgModule({
  declarations: [
    AppComponent,
    ListarUsuarioComponent,
    CrearUsuarioComponent,
    ActualizarUsuarioComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
