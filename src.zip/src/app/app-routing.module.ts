import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ListarUsuarioComponent } from './component/listar-usuario/listar-usuario.component';
import { CrearUsuarioComponent } from './component/crear-usuario/crear-usuario.component';
import { ActualizarUsuarioComponent } from './component/actualizar-usuario/actualizar-usuario.component';

const routes: Routes = [
  {path:'',pathMatch:'full',redirectTo:'listar-usuario'},
  {path:'listar-usuario',component:ListarUsuarioComponent},
  {path:'crear-usuario',component:CrearUsuarioComponent},
  {path:'actualizar-usuario/:id',component:ActualizarUsuarioComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
