import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { Usuario } from '../model/Usuario';
@Injectable({
  providedIn: 'root'
})
export class UsuarioService {
//API_URL='http://localhost/Apitransporcar/';
API_URL='http://localhost:3300/';
  constructor(private http:HttpClient) { }
//-- van todos los metodos para consumir la api 
//...listar todos los reguistros
getALL()
{
 // return this.http.get(this.API_URL+'getusuario.php');
 return this.http.get(this.API_URL+'usuarios/');
}
//---eliminar---
//----eliminar
deleteUsuario(id:string){
  if(confirm("Desea eliminar el cliente con id: "+id))
  {
   
    let dato ={'id':id}
    return this.http.delete(this.API_URL+'usuarios/'+id);
  }
  return this.getALL();
} 

//---- guarda en la API el cliente
saveUsuario(reg:Usuario)
{
  console.log(' listo para guardar ',reg);
  //return this.http.post(this.API_URL+'guardarusuario.php',reg);
  return this.http.post(this.API_URL+'usuarios/',reg);
}
//--- retorne un cliente dado un id
getUsuario(id:string)
{
  //console.log(' Ruta ',this.API_URL+'getusuario.php?id='+id);
  //return this.http.get(this.API_URL+'getusuario.php?id='+id);
  return this.http.get(this.API_URL+'usuarios/'+id);
}
//------ actualiza en la Bd llamando la API
updateUsuario(reg:Usuario)
{
  //return this.http.post(this.API_URL+'actualizarusuario.php', reg);
  return this.http.put(this.API_URL+'usuarios/', reg);
}


}//EndClass
