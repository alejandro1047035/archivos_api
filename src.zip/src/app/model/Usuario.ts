export interface Usuario{
    id: number,
    documento: string,
    nombres: string,
    apellidos: string,
    direccion: string,
    telefono: string,
    correo: string
};